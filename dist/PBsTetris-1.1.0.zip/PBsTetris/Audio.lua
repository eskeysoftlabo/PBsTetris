PBT=PBT or {}
local Audio={};Audio.__index=Audio;PBT.Audio=Audio
local ids={move='DEFAULT_CLICK',rotate='LOCKPICKING_CHAMBER_START',hold='ENCHANTING_POTENCY_RUNE_PLACED',lock='LOCKPICKING_CHAMBER_LOCKED',clear='SCRYING_CAPTURE_HEX_LARGE',quad='SCRYING_CAPTURE_GOAL',start='DUEL_START',win='DUEL_WON',lose='DUEL_FORFEIT'}
function Audio.New(saved) return setmetatable({saved=saved,last={}},Audio) end
function Audio:Play(kind)
 if self.saved.soundEnabled==false then return end
 local now=GetFrameTimeSeconds();if now-(self.last[kind] or -100)<(kind=='move' and .09 or .045) then return end
 self.last[kind]=now
 local id=SOUNDS and SOUNDS[ids[kind]]
 if id and PlaySound then PlaySound(id) end
end
function Audio:Bind(engine)
 if engine then engine.onEvent=function(kind) self:Play(kind) end end
end
function Audio:Sync(active)
 local enabled=active and self.saved.musicEnabled~=false
 if enabled and not self.owned and GetOverrideMusicMode and SetOverrideMusicMode and OVERRIDE_MUSIC_MODE_TRIBUTE then
  self.previous=GetOverrideMusicMode();self.mode=OVERRIDE_MUSIC_MODE_TRIBUTE
  if pcall(SetOverrideMusicMode,self.mode) then self.owned=true end
 elseif not enabled then self:Stop() end
end
function Audio:Stop()
 if self.owned then
  if GetOverrideMusicMode and GetOverrideMusicMode()==self.mode then pcall(SetOverrideMusicMode,self.previous) end
  self.owned=false;self.previous=nil
 end
end
