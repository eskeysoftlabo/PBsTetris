PBT=PBT or {}
local A={keys={}};PBT.App=A
function A:Alert(message) ZO_Alert(UI_ALERT_CATEGORY_ALERT,nil,message) end
function A:Engine() return self.solo and self.soloEngine or self.match.engine end
function A:ClearKeys() self.keys={};self.repeatAt=0 end
function A:Save()
 if self.soloEngine then self.saved.highScore=math.max(self.saved.highScore,self.soloEngine.score);self.saved.bestLines=math.max(self.saved.bestLines,self.soloEngine.lines) end
end
function A:Solo(restart)
 if self.match:Active() then self:Alert('対戦を終了してから、ひとりで挑戦してください。');return end
 self.solo=true
 if restart or not self.soloEngine then self:Save();self.soloEngine=PBT.Engine.New(math.random(1,2147483646),false) end
 self.audio:Bind(self.soloEngine);self.audio:Play("start");self.soloEngine.paused=false;self:ClearKeys();SCENE_MANAGER:Show('pbtGame');self.ui:Refresh()
end
function A:Challenge(peer)
 if self.match:Active() then self:Alert('進行中の対戦を終了してください。');return end
 if self.transport.error then self:Alert(self.transport.error);return end
 if not self.transport:Allowed(peer) then self:Alert('同じグループの、戦闘中ではない相手を招待してください。');return end
 self:Save();if self.soloEngine then self.soloEngine.paused=true end
 self.solo=false;self:ClearKeys()
 if self.match:Invite(peer) then SCENE_MANAGER:Show('pbtGame') end
end
function A:Hidden()
 self.audio:Stop()
 self:ClearKeys();self:Save()
 if self.soloEngine then self.soloEngine.paused=true end
 if self.match:Active() then self.match:Quit() end
end
function A:Playable()
 local e=self:Engine();return self.ui.scene:IsShowing() and e and not e.over and not e.paused and (self.solo or self.match.state=='playing')
end
function A:Input(key,down)
 if not self:Playable() then self:ClearKeys();return end
 self.keys[key]=down
 if down then
  if key=='left' or key=='right' then self:Engine():Move(key=='left' and -1 or 1);self.repeatAt=GetFrameTimeSeconds()+.16
  elseif key=='up' then self:Engine():Drop() end
 end
end
function A:ActionName(key)
 local e=self:Engine()
 if key=='music' then return self.saved.musicEnabled and 'BGM：入' or 'BGM：切' end
 if key=='primary' then
  if self.solo then return e.over and 'もう一度挑戦' or (e.paused and '再開' or '右回転') end
  return self.match.state=='invited' and '対戦を承諾' or '右回転'
 elseif key=='drop' then return '一気に落とす'
 elseif key=='hold' then return 'ホールド'
 elseif key=='ccw' then return '左回転'
 elseif key=='back' then return self.solo and e and not e.over and not e.paused and '一時停止' or (self.match:Active() and '対戦を終了して閉じる' or '閉じる') end
end
function A:Action(key)
 local e=self:Engine()
 if key=='music' then self.saved.musicEnabled=not self.saved.musicEnabled;self.audio:Sync(self:Playable())
 elseif key=='back' then
  self:ClearKeys()
  if self.solo and not e.over and not e.paused then e.paused=true;self:Save()
  else SCENE_MANAGER:Hide('pbtGame') end
 elseif key=='primary' and not self.solo and self.match.state=='invited' then self.match:Accept()
 elseif key=='primary' and self.solo and e.over then self:Solo(true)
 elseif key=='primary' and self.solo and e.paused then e.paused=false
 elseif self:Playable() then
  if key=='primary' then e:Rotate(1) elseif key=='ccw' then e:Rotate(-1) elseif key=='drop' then e:Drop() elseif key=='hold' then e:Hold() end
 end
 self.ui:Refresh()
end
function A:Initialize()
 self.saved=ZO_SavedVars:NewAccountWide('PBsTetrisSavedVariables',1,nil,{highScore=0,bestLines=0,soundEnabled=true,musicEnabled=true})
 self.audio=PBT.Audio.New(self.saved)
 self.transport=PBT.Transport.New(function(sender,p)
  if self.solo and self.ui.scene:IsShowing() then return end
  self.match:Receive(sender,p)
 end)
 self.match=PBT.Match.New({name=GetDisplayName(),now=GetFrameTimeSeconds,wall=GetTimeStamp,random=function() return math.random(1,2147483646) end,
  allowed=function(peer) return self.transport:Allowed(peer) end,send=function(peer,p) return self.transport:Send(peer,p) end,
  changed=function(m)
   if m.engine then self.audio:Bind(m.engine) end
   if m.state~=self.audioState then
    if m.state=='playing' then self.audio:Play('start') elseif m.state=='result' then self.audio:Play(m.terminal==0 and 'win' or 'lose') end
    self.audioState=m.state
   end
   if m.state=='invited' then self.solo=false;SCENE_MANAGER:Show('pbtGame') end
   if self.ui then self.ui:Refresh() end
  end})
 self.ui=PBT.UI.New(self);PBT.HookMenus(self)
 SLASH_COMMANDS['/pbt']=function(arg)
  if arg=='sound' then self.saved.soundEnabled=not self.saved.soundEnabled;self:Alert(self.saved.soundEnabled and '効果音：入' or '効果音：切')
  elseif arg=='debug' then d(self.transport.detail or self.transport.error or '通信初期化済み・開発用ID 510') else self:Solo() end
 end
 self.lastTick=GetFrameTimeSeconds();self.drawAt=0
 EVENT_MANAGER:RegisterForUpdate('PBsTetrisTick',16,function()
  local now=GetFrameTimeSeconds();local dt=math.min(.1,now-self.lastTick);self.lastTick=now
  if self:Playable() then
   local dx=(self.keys.left and -1 or 0)+(self.keys.right and 1 or 0)
   if dx~=0 and now>=self.repeatAt then self:Engine():Move(dx);self.repeatAt=now+.05 end
   self:Engine():Tick(dt,self.keys.down)
   if self:Engine().over then self:Save() end
  end
  self.audio:Sync(self:Playable())
  local e=self:Engine()
  if self.solo and e and e.over and self.finishedEngine~=e then self.finishedEngine=e;self.audio:Play("lose") end
  self.match:Tick(dt)
  if self.ui.scene:IsShowing() and now>=self.drawAt then self.drawAt=now+.033;self.ui:Refresh() end
 end)
 EVENT_MANAGER:RegisterForEvent('PBsTetris',EVENT_CONTROLLER_DISCONNECTED,function() self:Hidden();SCENE_MANAGER:Hide('pbtGame') end)
 EVENT_MANAGER:RegisterForEvent('PBsTetris',EVENT_PLAYER_DEACTIVATED,function() self:Hidden();SCENE_MANAGER:Hide('pbtGame') end)
 EVENT_MANAGER:RegisterForEvent('PBsTetris',EVENT_PLAYER_COMBAT_STATE,function(_,combat) if combat then self:Hidden();SCENE_MANAGER:Hide('pbtGame') end end)
end
EVENT_MANAGER:RegisterForEvent('PBsTetris',EVENT_ADD_ON_LOADED,function(_,name)
 if name=='PBsTetris' then EVENT_MANAGER:UnregisterForEvent('PBsTetris',EVENT_ADD_ON_LOADED);A:Initialize() end
end)
